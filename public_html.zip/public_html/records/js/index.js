$('#convert').click(function(){
  x = $('#inney').val();
  x = x.split('\t').join('</td><td>');
  x = x.split('\n').join('</td>\n\t</tr>\n\t<tr>\n\t\t<td>');
  x = '<table>\n\t<tr>\n\t\t<td>' + x + '</td>\n\t</tr>\n</table>\n';
  $('#output').text(x).focus().select();
  $('#render').html(x);
});